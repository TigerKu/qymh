<?php
//配置文件
return [
    'dispatch_success_tmpl'  => APP_PATH . 'mobile/view/index' . DS . 'dispatch_jump.html',
    'dispatch_error_tmpl'    => APP_PATH . 'mobile/view/index' . DS . 'dispatch_jump.html',
];