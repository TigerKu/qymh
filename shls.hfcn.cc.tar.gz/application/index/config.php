<?php
//配置文件
return [
    'dispatch_success_tmpl'  => APP_PATH . 'index/view/index' . DS . 'dispatch_jump.html',
    'dispatch_error_tmpl'    => APP_PATH . 'index/view/index' . DS . 'dispatch_jump.html',
];